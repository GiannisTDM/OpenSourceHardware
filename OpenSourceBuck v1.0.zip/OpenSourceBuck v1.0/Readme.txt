This project is intended to be a good base buck driver 
for the Laser hobbist community capable of supplying up to 3A.
By utilizing the files and/or information contained in them you agree to the following:

Shall not mass produce the driver and sell for a profit unless advising the head of the project
Giannis Koumoutsos/Giannis_TDM by emailing at giannislasershack@gmail.com so guidelines can be 
agreed upon.

Mass produce in this context means that a quantity of thirty (30) or more drivers were produced in a
run.

Said does not hold true if the individual is not selling them but produces said run for a project of
theirs. 

Thank you for reeding and enjoy the drivers!

Note: The BOM for the buck is in the KiCad scematic file.
      The gerbers will produce a 3x3 pannel of drivers 
      Assebly is intended to be done by hand.